//Task -1 snake game
import javax.swing.*;

public class Snake extends JFrame{

    Snake(){
        super("Snake Game(By Pratik_PM)");
        add(new Board());
        pack();

        setLocationRelativeTo(null);
        setResizable(false);

    }

    public static void main(String[] args){
        new Snake().setVisible(true);
    }
}